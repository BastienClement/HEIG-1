/*
 * File:   morsewav.h
 * Author: IICT
 *
 * Created on 23. avril 2013, 15:30
 */

#ifndef MORSEWAV_H
#define MORSEWAV_H

#include <string>

using namespace std;

void morseToWave(const char*  file,
                 const string morse);

#endif	/* MORSEWAV_H */

